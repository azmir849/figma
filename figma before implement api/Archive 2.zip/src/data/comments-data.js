
const comments_data = [
    {
      id: 1,
      children: "",
      img: "/assets/img/blog/comments/comment-1.jpg",
      name: "Eleanor Fant",
      date: "July 14, 2022",
      comment: <>So I said lurgy dropped a clanger Jeffrey bugger
      cuppa gosh David blatant have it, standard A bit of
      how's your father my lady absolutely.</>,
  
    },
   {
      id: 2,
      children: "children",
      img: "/assets/img/blog/comments/comment-2.jpg",
      name: "Eleanor Fant",
      date: "July 14, 2022",
      comment: <>So I said lurgy dropped a clanger Jeffrey bugger
      cuppa gosh David blatant have it, standard A bit of
      how's your father my lady absolutely.</>,
  
    },
    {
      id: 3,
      children: "",
      img: "/assets/img/blog/comments/comment-3.jpg",
      name: "JAMIL",
      date: "July 14, 2022",
      comment: <>So I said lurgy dropped a clanger Jeffrey bugger
      cuppa gosh David blatant have it, standard A bit of
      how's your father my lady absolutely.</>,
  
    },  
  
  ]

  export default comments_data
  