const blog_grid_data = [
    {
        id: 1,
        img: "/assets/img/blog/blog-thumb-3-01.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Educational Technology & Mobile Learning",
        user: "Karim Benzamin"

    },
    {
        id: 2,
        img: "/assets/img/blog/blog-thumb-3-02.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Computer Technology & Mobile Learning",
        user: "Karim Benzamin"

    },
    {
        id: 3,
        img: "/assets/img/blog/blog-thumb-3-03.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Architectural Engineering & Applying In Work",
        user: "Karim Benzamin"

    },
    {
        id: 4,
        img: "/assets/img/blog/blog-grid-04.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Mechanical Technology & Language Learning",
        user: "Karim Benzamin"

    },
    {
        id: 5,
        img: "/assets/img/blog/blog-grid-05.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Software Technology & Marketing Police",
        user: "Karim Benzamin"

    }, 
    {
        id: 6,
        img: "/assets/img/blog/blog-grid-06.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Front-End Technology & Working Skill",
        user: "Karim Benzamin"

    },
    {
        id: 7,
        img: "/assets/img/blog/blog-grid-07.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Science Technology & National Relation Learning",
        user: "Karim Benzamin"

    },
    {
        id: 8,
        img: "/assets/img/blog/blog-grid-08.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Pharmacy Learning & Applying Test",
        user: "Karim Benzamin"

    },
    {
        id: 9,
        img: "/assets/img/blog/blog-grid-09.jpg",
        data: "21 Jan 2022",
        category: "Education",
        title: "Medical Technology & Basic Knowladge Learning",
        user: "Karim Benzamin"

    },
]
export default blog_grid_data