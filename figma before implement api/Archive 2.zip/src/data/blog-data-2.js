const blog_data_2 = [
    {
        id: 1,
        date: "Jan 21 , 2022",
        img: "/assets/img/blog/blog-thumb--1.jpg",
        title: "Educational Technology & Mobile Learning",
        des: "Dramatically supply transparent deliverab before & you backward comp internal.",
      },
      {
        id: 2,
        date: "Jan 21 , 2022",
        img: "/assets/img/blog/blog-thumb--3.png",
        title: "Computer Technology &  Fild Work Experiences",
        des: "Dramatically supply transparent deliverab before & you backward comp internal.",
      },
      {
        id: 3,
        date: "Jan 21 , 2022",
        img: "/assets/img/blog/blog-sub-thumb-03.jpg",
        title: "Engineering Technology & Academic Learning",
        des: "Dramatically supply transparent deliverab before & you backward comp internal.",
      },
]
export default blog_data_2