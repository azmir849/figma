import React from 'react';
import SEO from '../common/seo';
import Blog from '../components/blog';
import WrapperTwo from '../layout/wrapper-2';

const index = () => {
    return (
        <WrapperTwo>
           <SEO pageTitle={"Blog"} /> 
           <Blog />
        </WrapperTwo>
    );
};

export default index;