const category_data_3 = [
    {
        id: 1,
        color: "cat-design",
        icon: "/assets/img/category/category2-1.png",
        title: "Design",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 2,
        color: "cat-deve",
        icon: "/assets/img/category/category2-2.png",
        title: "Development",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 3,
        color: "cat-market",
        icon: "/assets/img/category/category2-3.png",
        title: "Marketing",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 4,
        color: "cat-it",
        icon: "/assets/img/category/category2-4.png",
        title: "Software",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 5,
        color: "cat-video",
        icon: "/assets/img/category/category2-5.png",
        title: "Videography",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 6,
        color: "cat-business",
        icon: "/assets/img/category/category2-6.png",
        title: "Business",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 7,
        color: "cat-photo",
        icon: "/assets/img/category/category2-7.png",
        title: "Photography",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 8,
        color: "cat-music",
        icon: "/assets/img/category/category2-8.png",
        title: "Musical",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    
]
export default category_data_3