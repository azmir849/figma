const category_data_2 = [
    {
        id: 1,
        icon: "/assets/img/category/category-01.png",
        title: "Design Deve",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 2,
        icon: "/assets/img/category/category-02.png",
        title: "Development",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 3,
        icon: "/assets/img/category/category-03.png",
        title: "Marketing",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 4,
        icon: "/assets/img/category/category-04.png",
        title: "It & Software",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 5,
        icon: "/assets/img/category/category-05.png",
        title: "Videography",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 6,
        icon: "/assets/img/category/category-06.png",
        title: "Business Sys",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 7,
        icon: "/assets/img/category/category-07.png",
        title: "Photography",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    {
        id: 8,
        icon: "/assets/img/category/category-08.png",
        title: "Musical Intru",
        available: "236 Courses Available",
        course_link: "/course-grid"
    },
    
]
export default category_data_2