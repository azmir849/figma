// blog_page_data like this
const blog_page_data = [
  {
    id: 1,
    img: "/assets/img/blog/blog-in-1.jpg",
    slider_img: false,
    user: "JAMIL RAYHAN",
    date: " Dec 28, 2023",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [],
    title: "How to Succeed in the aws Certified Developer Associate Exam",
    des: (
      <>
        Compellingly exploit B2B vortals with emerging total linkage.
        Appropriately pursue strategic leadership whe intermandated ideas.
        Proactively revolutionize interoperable "outside the box" thinking with
        fully researched innovation. Dramatically facilitate exceptional
        architectures and bricks-and-clicks data. Progressively genera
        extensible e-services for.
      </>
    ),
  },
  {
    id: 2,
    img: "",
    slider_img: false,
    user: "JAMIL",
    date: " Dec 25, 2023",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [
      {
        video_tum: "/assets/img/blog/blog-in-5.jpg",
        videoId: "UPBMG5EYydo",
      },
    ],
    title:
      "Four Ways to Fullfill Your Task For Makes Parents Happy and Healthy",
    des: (
      <>
        Compellingly exploit B2B vortals with emerging total linkage.
        Appropriately pursue strategic leadership whe intermandated ideas.
        Proactively revolutionize interoperable "outside the box" thinking with
        fully researched innovation. Dramatically facilitate exceptional
        architectures and bricks-and-clicks data. Progressively genera
        extensible e-services for.
      </>
    ),
  },
  {
    id: 3,
    img: "",
    slider_img: [
      {
        img: "/assets/img/blog/blog-in-4.jpg",
      },
      {
        img: "/assets/img/blog/blog-in-5.jpg",
      },
      {
        img: "/assets/img/blog/blog-in-6.jpg",
      },
    ],
    user: "RAYHAN",
    date: " Dec 24, 2023",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [],
    title: "How to Understand Your Home Task and More Efficiently",
    des: (
      <>
        Compellingly exploit B2B vortals with emerging total linkage. Appropte
        pursu strategic leadership whe intermandated ideas. Lorem ipsum dolor
        sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
        ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
        exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
        dolore eu fugiat nulla pariatur.
      </>
    ),
  },
];

export default blog_page_data;
