const brands_data = [
    {
        img: "/assets/img/icon/brand-icon-01.png"
    },
    {
        img: "/assets/img/icon/brand-icon-02.png"
    },
    {
        img: "/assets/img/icon/brand-icon-03.png"
    },
    {
        img: "/assets/img/icon/brand-icon-04.png"
    },
    {
        img: "/assets/img/icon/brand-icon-05.png"
    },
    {
        img: "/assets/img/icon/brand-icon-01.png"
    },
    {
        img: "/assets/img/icon/brand-icon-02.png"
    },
]
export default brands_data