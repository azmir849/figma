const review_content = [
    {
        id: 1,
        img: "/assets/img/icon/c-details-avata-01.png",
        name: "Brooklyn Simmons",
        review_text: <>Synergistically foster 24/7 leadership rather than scalable platforms. Conveniently visualize installed base products before interactive results. Collaboratively restore corporate experiences and open-source applications.</>,
        review_time: "a week ago"
    },
    {
        id: 2,
        img: "/assets/img/icon/c-details-avata-02.png",
        name: "Leslie Alexander",
        review_text: <>Synergistically foster 24/7 leadership rather than scalable platforms. Conveniently visualize installed base products before interactive results. Collaboratively restore corporate experiences and open-source applications.</>,
        review_time: "a week ago"
    },
    {
        id: 3,
        img: "/assets/img/icon/c-details-avata-03.png",
        name: "Dianne Russell",
        review_text: <>Synergistically foster 24/7 leadership rather than scalable platforms. Conveniently visualize installed base products before interactive results. Collaboratively restore corporate experiences and open-source applications.</>,
        review_time: "a week ago"
    },
]

export default review_content