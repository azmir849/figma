const blog_masonry_data = [
    {
        id: 1,
        img: "/assets/img/blog/blog-sub-thumb-01.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Educational Technology & Mobile Learning",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },
    {
        id: 2,
        img: "/assets/img/blog/blog-sub-thumb-02.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Computer Technology & Academic Learning",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    }, 
    {
        id: 3,
        img: "/assets/img/blog/blog-thumb--3.png",
        data: "21 Jan 2023",
        category: "Education",
        title: "Electric Technology &  Realstick Learning",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    }, 
    {
        id: 4,
        img: "/assets/img/blog/blog-sub-thumb-03.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Medical Technology & Basic Knowladge Learning",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },
    {
        id: 5,
        img: "/assets/img/blog/blog-sub-thumb-01.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Pharmacy & Medicine Learning Test System",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },
    {
        id: 6,
        img: "/assets/img/blog/blog-thumb--1.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Mechanical Technology & Fild Work Experience",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },    
    {
        id: 7,
        img: "/assets/img/blog/blog-thumb--1.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Engineering Technology & Phone Learning",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },
    {
        id: 8,
        img: "/assets/img/blog/blog-thumb--3.png",
        data: "21 Jan 2023",
        category: "Education",
        title: "Technical Engineering Apply & Task In Fild",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },
    {
        id: 9,
        img: "/assets/img/blog/blog-sub-thumb-03.jpg",
        data: "21 Jan 2023",
        category: "Education",
        title: "Architectural Engineering & Applying In Work",
        des: <>Dramatically supply transparent deliverab before & you backward comp internal.</>,
        post_time: "2 minute read"
    },

]
export default blog_masonry_data